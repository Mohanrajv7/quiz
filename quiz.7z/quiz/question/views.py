from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home_page(request):
    return render(request, "home.html" ,{})

def english_quiz(request):
    return render(request, "english.html" ,{})

def maths_quiz(request):
    return render(request, "maths.html" ,{})

def science_quiz(request):
    return render(request, "science.html" ,{})