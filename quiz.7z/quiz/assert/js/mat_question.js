var question=[
	["  HCF of 8, 9, 25 is","8","9","25","1","1"],
	["  The product of a rational and irrational number is","rational","irrational","both of above","none of above","irrational"],
	["  If b = 3, then any integer can be expressed as a =","3q, 3q+ 1, 3q + 2","3q","3q+1","nono of above","3q, 3q+ 1, 3q + 2"],
	["  The product of three consecutive positive integers is divisible by","4","6","no comman factor","1","6"],
	["  The set A = {0,1, 2, 3, 4, …} represents the set of","whole number","integers","natural number","even number","whole number"],
	["  Which number is divisible by 11?","1516","1452","1011","1121","1452"],
	["  The least number that is divisible by all the numbers from 1 to 8 (both inclusive) is","840","2520","8","420","840"],
	["  The product of two consecutive natural numbers is always:","odd number","even number","primenumber","even or odd","even number"],
	["  The number in the form of 4p + 3, where p is a whole number, will always be","even","odd","even or odd","multiple of 3","odd"],
	["  If LCM (77, 99) = 693, then HCF (77, 99) is","11","7","9","22","11"]
];