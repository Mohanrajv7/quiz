var question=[
	["  Which one of the following salts does not contain water of crystallisation?","Blue vitriol","Baking soda","Washing soda","Gypsum","Baking soda"],
	["  In terms of acidic strength, which one of the following is in the correct increasing order?","Water < Acetic acid < Hydrochloric acid","Water < Hydrochloric acid < Acetic acid","Acetic acid < Water < Hydrochloric acid"," Hydrochloric acid < Water < Acetic acid","Water < Acetic acid < Hydrochloric acid"],
	["  Brine is an","aqueous solution of sodium hydroxide","aqueous solution of sodium carbonate","aqueous solution of sodium chloride","aqueous solution of sodium bicarbonate","aqueous solution of sodium chloride"],
	["  At what temperature is gypsum heated to form Plaster of Paris?","90°C","100°C","110°C","120°C","100°C"],
	["  Which of the following are energy foods?","Carbohydrates and fats"," Proteins and mineral salts","Vitamins and minerals","Water and roughage","Carbohydrates and fats"],
	["  Roots of the plants absorb water from the soil through the process of:","diffusion","transpiration","osmosis","None of these","osmosis"],
	["  In amoeba, food is digested in the:","food vacuole"," mitochondria","pseudopodia","chloroplast","food vacuole"],
	["  For a real object, which of the following can produce a real image?","Plane mirror","Concave mirror"," Concave lens","Convex mirror","Concave mirror"],
	["  The angle of incidence i and refraction r are equal in a transparent slab when the value of i is"," 0°","45°","90°","depend on the material of the slab"," 0°"],
	["  A divergent lens will produce","always real image","always virtual image","both real and virtual image","none of these","always virtual image"]
];