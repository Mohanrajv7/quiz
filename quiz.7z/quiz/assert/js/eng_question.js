var question=[
    ["  I _______ tennis every sunday morning","play","playing","am playing","am paly","play"],
    ["  Don't make so much noise. Noriko _______ to study for her ESL test!","try","trying","is trying","tried","is trying"],
    ["  How many students in your class _______ from Korea?","comes","come","coming","came","come"],
    ["  Weather report:It's seven o'clock in Frankfurt and _______ .","there is snow","it`s snowing","it snows","it snowed","it`s snowing"],
    ["  Babies _______ when they are hungry.","cry","cried","crying","cries","cry"],
    ["  I think I _______ a new calculator. This one does not work properly any more.","need","needs","needed","have need","need"],
    ["	 Sorry, you can't borrow my pencil. I _______ it myself.","use","using","used","am using","am using"],
    ["  What time _______","train leaves?","train leaving?","train is leaving?","does the train leave?","does the train leave?"],
    ["  I _______ for my pen. Have you seen it?","will look","looking","look","am looking","am looking"],
    ["The phone _______ Can you answer it, please?","rings","ring","rang","is ringing","is ringing"]
];