var quiz_display  = document.querySelector(".quiz_plain");
var result_display = document.querySelector(".result_plain");
var main = document.querySelector(".main");
var start_btn = document.querySelector("#start_btn");
main.style.display="none";
result_display.style.display="none";
var mark=0,count=0,start_time;
function time()
{
	var start_date=new Date();
        start_time=start_date.getTime();
}
function display()
{	
      result_display.style.display="none";
      main.style.display="";
  if(count>=question.length){
	  result_display.style.display="";
	  main.style.display="none";
	  result_display.innerHTML+="<p>Quiz complete</p>";
	  if(mark>=5)
	  {
	  result_display.innerHTML+="<br><p>you pass, got "+mark+" correct answer<p>";
	  }
	  else
	  {
	  result_display.innerHTML+="<br><p>you Fail, got "+mark+" correct answer<p>";
	  }
	 var end_date=new Date();
     var end_time=end_date.getTime();
	 var time=end_time-start_time;
	  time=Math.round(time/1000);
	  result_display.innerHTML+="<br><p>Time taken to finish the quiz :"+time+"sec</p>";
	  mark=0;
	  count=0;
  }
  else{
    var qus=question[count][0];
	var option_a=question[count][1];
	var option_b=question[count][2];
	var option_c=question[count][3];
	var option_d=question[count][4];
	var question_no=count+1;
	quiz_display.innerHTML="<center><h5>Quiz Application</h5><hr></center>";
    quiz_display.innerHTML+="<h3><span>   "+question_no+"</span>."+qus+"</h3><br>";
	quiz_display.innerHTML+="<div class='option' onclick='check(this)'>"+option_a+"</div><br>";
	quiz_display.innerHTML+="<div class='option' onclick='check(this)'>"+option_b+"</div><br>";
	quiz_display.innerHTML+="<div class='option' onclick='check(this)'>"+option_c+"</div><br>";
	quiz_display.innerHTML+="<div class='option' onclick='check(this)'>"+option_d+"</div><br>";	
  }
}
function check(selected_option)
{	
	var option_e=question[count][5];//This option is correct answer
	var selected_ans=selected_option.textContent;
	var get_option = document.querySelectorAll(".option");
		for(i=0; i < get_option.length; i++){
          if(get_option[i].textContent==option_e)
		  {
			 var corr_ans=get_option[i];
	}
		}
	for(i=0;i<get_option.length;i++)
	{
        get_option[i].setAttribute("onclick", "");
    }
	if(selected_option.textContent==option_e)
		{
		selected_option.insertAdjacentHTML("beforeend", "&#10004");	
		selected_option.style.color="green";
		count++;
		mark++;
		}
	else{
		selected_option.insertAdjacentHTML("beforeend", "&#10060");
		selected_option.style.color="red";
		corr_ans.insertAdjacentHTML("beforeend", "&#10004");
		corr_ans.style.color="green";
		count++;
	}
	quiz_display.innerHTML+="<button id='next_btn' onclick='display()'> Next question</button>";
}